# Pulse — Social Media Engagement Agent

Pulse is a prototype engagement agent designed to help a brand monitor social interactions, review sentiment and urgency, and prepare suggested replies from a unified workspace.

## Live Demo
https://site-ac74264f1b8c4cbc9f45b0684e4c426c.freebuff.page/

## Prototype Status
This project is currently a **demo prototype**. The interface uses sample data and does not have live social-media API connections. No real messages are published or replied to from this demo.

## Main Features

- **Dashboard:** Overview of interactions, items awaiting review, high-priority items, published replies, interaction trends, and sentiment split.
- **Inbox:** Browse sample comments/messages and review sentiment, urgency, status, and suggested replies.
- **Analytics:** View engagement and sentiment insights.
- **Social Accounts:** Demo account cards for Instagram, X, Facebook, LinkedIn, and YouTube.
- **Settings:** Configure brand name, tone, preferred language, and response guidelines.

## Screenshots

Screenshots are included in the `screenshots/` folder:
- Dashboard
- Inbox
- Social Accounts
- Settings

## Tech / Implementation Notes

The visible prototype indicates an offline/demo setup with sample data and a fallback template-based reply generator. The exact source code and implementation stack should be added to this repository by the project author if available.

## Important Limitations

- Sample data only.
- Social accounts are not connected to live APIs.
- Replies shown in the demo are not live-published.
- Do not enter real account credentials or API keys into this demo.

## Project Verification

This repository package currently contains project documentation and screenshots. **It does not contain the original website source code.** Add the actual source code, configuration files, and setup instructions before presenting this as a complete source-code repository.
